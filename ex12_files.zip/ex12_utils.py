def load_words_dict(file_path):
    pass


def is_valid_path(board, path, words):
    pass


def find_length_n_words(n, board, words):
    pass